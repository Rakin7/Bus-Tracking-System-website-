from typing import Dict, Any, Optional

import requests

DISTANCE_CALCULATION_URL = "https://maps.googleapis.com/maps/api/distancematrix/json?origins={}%2C{}&destinations={}%2C{}&departure_time=now&key=AIzaSyCuabQFSSO6F_0edXfRaHABN02RobWbuAs"


def calculate_distance(source: Dict[str, float], destination: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if any(item is None for item in
           [source.get("lat"), source.get("long"), destination.get("lat"), destination.get("long")]):
        return None

    url = DISTANCE_CALCULATION_URL.format(source.get("lat"), source.get("long"),
                                          destination.get("lat"), destination.get("long"))
    response = requests.get(url)
    response.raise_for_status()

    res_json = response.json()
    # print(res_json)
    query_status = res_json.get("status")
    if query_status != "OK":
        raise ValueError("call to google maps api failed")
    try:
        distance_status = res_json.get("rows")[0].get("elements")[0]["status"]
        if distance_status == "OK":
            return {
                "bus_address": res_json["destination_addresses"][0],
                "your_position_address": res_json["origin_addresses"][0],
                "distance": res_json.get("rows")[0].get("elements")[0]["distance"],
                "duration": res_json.get("rows")[0].get("elements")[0]["duration"],
                "duration_in_traffic": res_json.get("rows")[0].get("elements")[0]["duration_in_traffic"],
            }
        else:
            raise ValueError("source or destination parameter is invalid")
    except:
        raise ValueError("JSON response has invalid schema!")
