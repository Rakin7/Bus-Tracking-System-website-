from flask import Flask, request, make_response, jsonify
from flask_cors import CORS

from database import get_nearest_bus, add_location, seed_data, get_all_buses, get_complete_data_dump

app = Flask(__name__)
CORS(app)


@app.before_first_request
def seed():
    seed_data()


@app.route("/")
def home():
    urls = [str(url) for url in app.url_map.iter_rules()]
    urls.sort()
    urls.pop()
    return make_response(jsonify({
        "msg": "Bus Tracker api version 1.0",
        "available_routes": urls
    }), 200)


@app.route("/api/v1/tracker/all")
def all_data():
    return make_response(jsonify(
        get_complete_data_dump()
    ), 200)


@app.route('/api/v1/tracker/all/name')
def buses():
    return make_response(jsonify(
        get_all_buses()
    ), 200)


@app.route('/api/v1/tracker/track/<string:bus_id>/save')
def save_record(bus_id: str):
    if "lat" not in request.args or "long" not in request.args:
        return make_response(jsonify({
            "error": {
                "msg": "lat and lang is mandatory in query parameter"
            }
        }), 400)
    lat = request.args.get("lat", default=None, type=float)
    long = request.args.get("long", default=None, type=float)
    if any(item is None for item in [lat, long]):
        return make_response(jsonify({
            "error": {
                "msg": "FLOAT data type are expected for lat and long value"
            }
        }), 400)
    body = {
        "lat": lat,
        "long": long
    }
    locations = add_location(bus_id, location=body)
    return make_response(jsonify({
        "status": "okay",
        "locations": locations
    }), 200)


@app.route('/api/v1/tracker/track/<string:bus_id>')
def bus_tracker(bus_id: str):
    if request.method == "GET":
        lat = request.args.get("lat", type=float, default=None)
        long = request.args.get("long", type=float, default=None)
        if any(item is None for item in [lat, long]):
            return make_response(jsonify({
                "error": {
                    "msg": "lat and long param is empty or invalid"
                }
            }), 400)

        try:
            origin = {
                "lat": lat,
                "long": long
            }
        except Exception as ex:
            return make_response(jsonify({
                "error": {
                    "msg": str(ex)
                }
            }), 500)

        nearest_bus_location = get_nearest_bus(bus_id, source=origin)
        return make_response(jsonify(
            nearest_bus_location
        ), 200)


if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=80)
