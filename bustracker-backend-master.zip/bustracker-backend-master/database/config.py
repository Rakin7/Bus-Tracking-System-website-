import os

DATA_POINT_LIMIT = os.getenv("DATA_POINT_LIMIT", 50)
