import math
from typing import Dict, Union, List, Any, Optional

import googlemaps
from database.config import DATA_POINT_LIMIT
from database.repository import DATABASE_DICTIONARY, deque


def degree_to_rad(num):
    return num * (math.pi / 180)


def calculate_distance_between_two_points(source: Dict[str, float], destination: Dict[str, Any]) -> float:
    radius = 6371
    # print("calc distance", source, destination)
    dLat = degree_to_rad(source.get("lat") - destination.get("lat"))
    dLang = degree_to_rad(source.get("long") - destination.get("long"))

    a = (math.sin(dLat / 2) ** 2) + \
        math.cos(degree_to_rad(source.get("lat"))) * math.cos(degree_to_rad(destination.get("lat"))) * \
        (math.sin(dLang / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    d = radius * c
    return d


def get_all_buses() -> List[Union[int, str]]:
    return list(DATABASE_DICTIONARY.keys())


def add_location(bus_id: str, location: Dict[str, float]) -> List[Dict[str, float]]:
    if bus_id not in DATABASE_DICTIONARY:
        DATABASE_DICTIONARY[bus_id.lower()] = deque([], DATA_POINT_LIMIT)
    DATABASE_DICTIONARY[bus_id].append(location)
    return get_all_locations(bus_id)


def get_all_locations(bus_id: str) -> List[Dict[str, float]]:
    if bus_id not in DATABASE_DICTIONARY:
        return []
    locations = list(DATABASE_DICTIONARY[bus_id])
    return locations


def get_complete_data_dump():
    buses = get_all_buses()
    res = {}
    for bus in buses:
        res[bus] = get_all_locations(bus)
    return res


def get_nearest_bus(bus_id: str, source: Dict[str, float]) -> Optional[Dict[str, Any]]:
    locations = get_all_locations(bus_id)
    # print("locations", locations)
    if not locations:
        return {}
    min_distance = float("inf")
    bus_location = {}
    location = None
    for loc in locations:
        dis = calculate_distance_between_two_points(source, loc)
        if dis < min_distance:
            min_distance = dis
            location = loc
            bus_location = loc
    if not bus_location:
        return {}
    map_distance = googlemaps.calculate_distance(source, bus_location)
    if not map_distance:
        return {}
    map_distance["bus_location"] = location
    return map_distance


def seed_data():
    buses = ["robrob", "alif", "himachol", "projapoti", "jabalenur"]
    LATSTART = 23.4111
    LATEND = LATSTART + 2
    LONGSTART = 90.1000
    LONGEND = LONGSTART + 2

    import random

    for _ in range(250):
        add_location(random.choice(buses),
                     {"lat": random.uniform(LATSTART, LATEND), "long": random.uniform(LONGSTART, LONGEND)})
