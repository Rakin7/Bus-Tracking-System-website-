from collections import deque
from typing import Dict, Union

DATABASE_DICTIONARY: Dict[Union[int, str], deque] = dict()
